# cú pháp 
# for <Biến lặp> in <chuỗi lặp>:
#     <khối lệnh>

# for i in "Python":
#     print(i)

# n = int(input("n="))
# for i in range(100,n+1):
#     print(i, end=" ")
    
    
# Viết chương trình in ra màn hình các số từ 2 - 90
# Viết chương trình in ra màn hình các số chẵn từ 1 đến n

# n = int(input("Nhập n = "))

# for j in range(1,n+1):
#     if j % 2 == 0:
#         print(j," là số chẵn")

#  Viết chương trình tính tổng và in ra màn hình các số chẵn từ 1 đến n
n = int(input("Nhập n= "))
tong = 0
for i in range(1,n + 1):
    if i % 2 == 0:
        tong = tong + i
    
print("Kết quả: ",tong)