# fruit = ['banana', 'mango', 'cherry', 'gun']
# print(fruit[2])

str1 = "hello world"
# len(): đếm số lượng kí tự có trong chuỗi
print(len(str1))
# print(str1[4])
print(str1[5:]) # in từ vị trí thứ 6 đến hết
print(str1[:5]) # in từ đầu đến vị trí thứ 6
print(str1[2:6]) # in từ vị trí thứ 3 đến vị trí thứ 6

# tạo 1 chuỗi trên 10 kí tự. Thực hiện những yêu cầu sau.
# - in ra chuỗi từ vị trí thứ 6 trở đi
# - in ra chuỗi từ vị trí thứ 2 đến vị trí thứ 8
# - in ra chuỗi đến vị trí thứ 10