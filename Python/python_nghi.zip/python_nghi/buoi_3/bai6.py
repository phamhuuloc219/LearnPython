number = int(input("number="))

if number> 0:
    print(f"số {number} là số dương")
elif number < 0 :
    print(f"số {number} là số âm")
else:
    print("số 0")