# 1.Viết chương trình in ra màn hình các số
# chia hết cho 3 và 5 trong khoảng từ 1-n
# n = int(input("Nhập n = "))
# for i in range(1, n+1):
#     if i % 3 == 0 and i % 5 == 0:
#         print(i)
# 2.Viết chương trình in ra màn hình các số 
# lẻ trong khoảng từ 10-n
# 3. Viết chương trình tính tổng các số từ 
# 1-n
# 4. Viết chương trình tính tổng các số lẻ
# từ 1-n
# 5. Viết chương trình tính tổng các số lẻ
# chia hết cho 7 trong khoảng từ 100 - n

#  Viết chương trình tính tổng và in ra màn hình các số chẵn
# từ 1 đến n
# n = int(input("Nhập n= "))
# tong = 0
# for i in range(1,n + 1):
#     if i % 2 == 0:
#         tong = tong + i
    

# print("Kết quả: ",tong)

# 10. Nhập số nguyên n. Tính giá trị biểu thức
# S= 1x2 + 2x3 + 3x4 + ... + n(n+1).

# n = int(input("Nhập n= "))
# tong = 0
# for j in range(1, n+1):
#     tong = tong + j * (j+1)
# print("tổng = ", tong)









