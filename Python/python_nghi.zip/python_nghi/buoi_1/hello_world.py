#  Cú pháp tạo biến
# tên_biến = giá_trị
print("Hello world")

number = 219 # số nguyên
print(number)
number_b = 21.9 # số thực
print(number_b)
name = "Hom nay toi di hoc python" # chuỗi
print(name)
b = "True False"
print(b)
is_happy = True # Đúng/Sai (boolean) True = Đúng, False = Sai
print(is_happy)
# Tạo 4 biến mang 4 kiểu dữ liệu khác nhau và in ra màn hình 4 biến đó
