name = input("Nhập tên: ")
print("Tên bạn vừa nhập là: ",name)

number = int(input("Nhập số nguyên: "))
print("Số nguyên bằng: ",number)

number_b = float(input("Nhập số thực: "))
print("Số thực bằng: ",number_b)